/*************************************************************************************************/
/*  "A Sofware program for Calculating True Steady-State Metabolite Concentrations               */
/*	                 	in Large-Scale Metabolic Reaction Network Models"						 */
/*                                                                                               */
/*      Runge-Kutta medethod and S-system method are used                                        */
/*            to calculate True Steady-State Metabolite Concentrations.                          */
/*      The complex variable method is used to differentiate a given function.                   */
/*	    The calculated values are given within round-off errors.                                 */
/*	                                                                     (2018, June 14)         */
/*************************************************************************************************/

#include "stdafx.h"//#include <stdio.h>

#include <stdlib.h>
#include <malloc.h>
#include <math.h>
#include <complex>
using namespace std;
#include <windows.h>
#include <time.h> 
#include "./InputFile/equation.h"

double RKre = 1.0e-3;	/*Change the value of less than 1.0e-1, if necessary.*/

void formula(complex<double> *x, complex<double> *fx, complex<double> **v, complex<double> *sv, int nd1, int ni, int cv, complex<double> **stoin);

void timecourse();
void steady();

void gj(double **a, int nd, int na);
void coe_s(double *xp, double *fxp, double **vp, double *svp, double **stoin, double *as, double *bs, double **gs, double **hs, int nd1, int ni, int cv);
void complex_step2(complex<double> *C_xp, double **dv0, double **dv1, complex<double> *C_fxp, complex<double> **C_vp, complex<double> *C_svp, complex<double> **C_stoin, int nd1, int ni, int cv);

void fo(int *nd, int *ni, int *cv, double *q, int mode);
void fo1(int *nd, int *ni, int *cv);
void fo2(double *t_start, double *t_end, double *t_samp, double *sub_div);
void fo3(int *iflagtime);
void fo4(double **stoin, int nd, int ni, int cv);

int* i_vector(int n);
double* d_vector(int n);
double** d_matrix(int m, int n);
void free_d_matrix(int m, double **a);

complex<double>* C_d_vector(int n);
complex<double>** C_d_matrix(int m, int n);
void free_C_d_matrix(int m, complex<double> **a);

//--------------------------------------------------------------------//
#define input_initial "./InputFile/initial.dat"
#define input_rungekutta "./InputFile/integration.dat"

#define output "./OutputFile/Steady-state_Conc.dat"
#define output_pre "./OutputFile/RK_Conc.dat"
#define output_t "./OutputFile/timecourse.dat"
//--------------------------------------------------------------------//
//Files for perforance evaluation
#define caltime_output "./PerforanceFile/caltime.dat"
#define caltime_output_steady "./PerforanceFile/caltime_steady.dat"
#define caltime_Ssys "./PerforanceFile/solution_Ssys.dat"
//--------------------------------------------------------------------//

#define Step 1.0e-100
const complex<double> iu(0, 1);
int iflagtime;
errno_t error;

void main() {
	FILE *ftw;
	clock_t start_t, end_t, mid_t;

	if (error = fopen_s(&ftw, caltime_output, "w") != 0) {
		printf("Cannot open 'caltime.dat' file curent drive.\n");
		getchar();
		exit(1);
	}

	fprintf(ftw, "Calculating true steady-state metabolite concentrations by R-K method & S-system method\n");
	fclose(ftw);
	//-------------------------------------------------------------------------------------------------------------------------------//

	fo3(&iflagtime);

	if (error = fopen_s(&ftw, caltime_output, "a") != 0) {
		printf("Cannot open 'caltime.dat' file curent drive.\n");
		getchar();
		exit(1);
	}

	start_t = GetTickCount();
	fprintf(ftw, "Integration start:%23.15e\n", (double)start_t);
	fclose(ftw);
	//----------------------------------------------------------------------------//
	if (iflagtime == 1) timecourse();	//Runge-Kutta method
										//----------------------------------------------------------------------------//
	if (error = fopen_s(&ftw, caltime_output, "a") != 0) {
		printf("Cannot open 'caltime.dat' file curent drive.\n");
		getchar();
		exit(1);
	}
	end_t = GetTickCount();
	fprintf(ftw, "Integration end:%23.15e\n", (double)end_t);
	mid_t = end_t - start_t;
	fprintf(ftw, "Integration took %23.15e count [%23.15e sec].\n", (double)mid_t, (double)mid_t / 1000);
	printf("Integration took %d count [%4.2f sec].\n\n", mid_t, (double)mid_t / 1000);
	fclose(ftw);
	//-------------------------------------------------------------------------------------------------------------------------------//
	if (error = fopen_s(&ftw, caltime_output, "a") != 0) {
		printf("Cannot open 'caltime.dat' file curent drive.\n");
		getchar();
		exit(1);
	}
	start_t = GetTickCount();
	fprintf(ftw, "Steady-State Calculation start:%23.15e\n", (double)start_t);
	printf("Steady-State Calculation start [%4.2f sec]\n", (double)start_t / 1000);
	//----------------------------------------------------------------------------//
	steady();	//S-system method
				//----------------------------------------------------------------------------//
	end_t = GetTickCount();
	fprintf(ftw, "Steady-State Calculation end:%23.15e\n", (double)end_t);
	printf("Steady-State Calculation end [%4.2f sec]\n", (double)end_t / 1000);
	mid_t = end_t - start_t;
	fprintf(ftw, "Steady-State Calculation end took %23.15e count [%23.15e sec].\n", (double)mid_t, (double)mid_t / 1000);
	printf("Steady-State Calculation end took %d count [%4.2f sec].\n\n", mid_t, (double)mid_t / 1000);
	fclose(ftw);

	fclose(ftw);

	printf("Calculation End\n");
	getchar();
}


// ***************************************************
void timecourse()
{
	FILE *ftw;
	if (error = fopen_s(&ftw, caltime_output, "a") != 0) {
		printf("Cannot open 'caltime.dat' file curent drive.\n");
		getchar();
		exit(1);
	}
	fprintf(ftw, "Setting: RKre (Relative error):%23.15e\n", RKre);
	fclose(ftw);

	double *xp, *fxp, **vp, *svp;
	double **stoin;
	double t_start, t_end, t_samp, sub_div;
	int i, j, iflag = 0;
	int nd, ni, cv, nd1, na1, cv1;

	FILE *fpw;

	fo1(&nd, &ni, &cv);
	cv1 = cv + 1;
	nd1 = nd + 1;
	na1 = nd1 + ni;
	xp = d_vector(na1);
	fo(&nd, &ni, &cv, xp, 0);

	fxp = d_vector(nd1);
	vp = d_matrix(nd1, 2);
	svp = d_vector(cv1);

	stoin = d_matrix(nd1, cv1);
	fo4(stoin, nd, ni, cv);

	fo2(&t_start, &t_end, &t_samp, &sub_div);

	//--------------------------------------------------------------------------------------------//

	for (i = 1; i<nd1; i++) printf("x[%d]=%lf\n", i, xp[i]);

	int  m;
	double s1, s2, s3, s4, s5, s6;
	double *k, *y, *q, *y0;
	double t, z, h;

	k = d_vector(nd1);
	y = d_vector(na1);
	y0 = d_vector(nd1);
	q = d_vector(nd1);

	for (i = 1; i<na1; i++) y[i] = xp[i];

	if (error = fopen_s(&fpw, output_t, "w") != 0) {
		printf("Cannot open 'timecourse.dat' file curent drive.\n");
		getchar();
		exit(1);
	}

	s1 = 1.0 - 0.5*sqrt(2.0);/*s1=(2.0-sqrt(2.0))/2.0;*/
	s2 = 1.5*sqrt(2.0) - 2.0;/*s2=(3.0*sqrt(2.0)-4.0)/2.0;*/
	s3 = 2.0 - sqrt(2.0);
	s4 = 1.0 + 0.5*sqrt(2.0); //s4=(2.0+sqrt(2.0))/2.0;
	s5 = -(1.5*sqrt(2.0) + 2.0); /*s5=-(3.0*sqrt(2.0)+4.0)/2.0;*/
	s6 = 2.0 + sqrt(2.0);

	h = t_samp / sub_div;
	z = t_start;

	t = t_start;
	printf("%lf", t);
	fprintf(fpw, "%lf", t);
	for (i = 1; i<nd1; i++) {
		fprintf(fpw, "\t%23.15e", y[i]);
	}
	fprintf(fpw, "\n");

	//--------------------------------------------------------------------------------------------
	complex<double> *C_y, *C_fxp, **C_vp, *C_svp, **C_stoin;

	C_y = C_d_vector(na1);
	C_fxp = C_d_vector(nd1);
	C_vp = C_d_matrix(nd1, 2);
	C_svp = C_d_vector(cv1);
	C_stoin = C_d_matrix(nd1, cv1);

	for (j = 1; j<na1; j++)
		C_y[j] = y[j];

	for (i = 1; i < nd1; i++) {
		for (j = 1; j < cv1; j++) C_stoin[i][j] = stoin[i][j];
	}
	//--------------------------------------------------------------------------------------------


	while (fabs((z - t_end) / t_end)>1.0e-13) {

		for (i = 1; i<nd1; i++) y0[i] = real(C_y[i]);

		for (m = 0; m<sub_div; m++) {
			t = h*(double)m + z;

			formula(C_y, C_fxp, C_vp, C_svp, nd1, ni, cv, C_stoin);
			for (j = 1; j<nd1; j++) {

				k[j] = h*real(C_fxp[j]);
				C_y[j] = C_y[j] + 0.5*k[j];
				q[j] = k[j];
			}

			t = 0.5*h + h*(double)m + z;

			formula(C_y, C_fxp, C_vp, C_svp, nd1, ni, cv, C_stoin);
			for (j = 1; j<nd1; j++) {
				k[j] = h*real(C_fxp[j]);
				C_y[j] = C_y[j] + s1*(k[j] - q[j]);
				q[j] = s2*q[j] + s3*k[j];
			}

			t = 0.5*h + h*(double)m + z;
			formula(C_y, C_fxp, C_vp, C_svp, nd1, ni, cv, C_stoin);
			for (j = 1; j<nd1; j++) {
				k[j] = h*real(C_fxp[j]);
				C_y[j] = C_y[j] + s4*(k[j] - q[j]);
				q[j] = s5*q[j] + s6*k[j];
			}

			t = h*(double)(m + 1) + z;
			formula(C_y, C_fxp, C_vp, C_svp, nd1, ni, cv, C_stoin);
			for (j = 1; j<nd1; j++) {
				k[j] = h*real(C_fxp[j]);
				C_y[j] = C_y[j] + k[j] / 6.0 - q[j] / 3.0;
			}
		}

		fprintf(fpw, "%lf", t);
		printf("%7.3lf", t);

		for (i = 1; i<nd1; i++) {
			fprintf(fpw, "\t%23.15e", real(C_y[i]));
		}
		fprintf(fpw, "\n");

		for (i = 1; i<nd1; i++) {
			if (fabs((real(C_y[i]) - y0[i]) / y0[i])>RKre) {
				iflag = 0;
				break;
			}
			else {
				iflag = 1;
			}
		}

		z += t_samp;

		if (iflag == 1) {
			printf("\nInitial guesses estimated.\n");
			printf("<Relative errors>\n");
			for (i = 1; i<nd1; i++) printf("X[%d]:%23.15e\n", i, fabs((real(C_y[i]) - y0[i]) / y0[i]));
			break;
		}
	}

	if (iflag != 1) {
		printf("The calculation was executed until the time end.\nPress any key to start calcuration.");
	}

	fclose(fpw);

	if (error = fopen_s(&fpw, output_pre, "w") != 0) {
		printf("Cannot open 'RK_Conc.dat' file curent drive.\n");
		getchar();
		exit(1);
	}

	fprintf(fpw, "%d\n%d\n%d\n", nd, ni, cv);
	for (i = 1; i<na1; i++) {
		fprintf(fpw, "%23.15e\n", real(C_y[i]));
	}
	fclose(fpw);
	free(k);
	free(q);
	free(y);
	free(y0);
	free(xp);
	free(fxp);
	free_d_matrix(nd1, vp);
	free(svp);

	free_d_matrix(nd1, stoin);
	//------------------------------------------------------//
	free(C_y);
	free(C_fxp);
	free_C_d_matrix(nd1, C_vp);
	free(C_svp);
	free_C_d_matrix(nd1, C_stoin);
}

void steady()
{
	FILE *ftws;
	clock_t start_t, end_t, mid_t;

	if (error = fopen_s(&ftws, caltime_output_steady, "w") != 0) {
		printf("Cannot open 'caltime_steady.dat' file curent drive.\n");
		getchar();
		exit(1);
	}

	fclose(ftws);

	double *xp, *fxp, **df, **vp, *svp;
	double *as, *bs, **gs, **hs;
	double **a, *xp0;
	double **stoin;
	double sgm = 1, eps = 1.0e-12;
	int i, j, count;
	int nd, nf, ni, na, cv, cv1, nd1, na1, trymax = 20;

	double max;
	bool conv;
	bool retry;
	conv = false;
	retry = false;

	FILE *fpw;

	fo1(&nd, &ni, &cv);
	na = nd + ni;
	cv1 = cv + 1;
	nd1 = nd + 1;
	na1 = na + 1;
	xp = d_vector(na1);
	//-----------------------------
	if (iflagtime == 1 || iflagtime == 2)
		fo(&nd, &ni, &cv, xp, 2);
	else
		fo(&nd, &ni, &cv, xp, 0);
	//-----------------------------	
	fxp = d_vector(nd1);
	vp = d_matrix(nd1, 2);
	svp = d_vector(cv1);
	df = d_matrix(nd1, nd1 + 1);

	nf = nd1;
	printf("nd=%d ni=%d cv=%d\n", nd, ni, cv);
	//----------------------------------
	stoin = d_matrix(nd1, cv1);
	fo4(stoin, nd, ni, cv);

	/*=====================================================*/
	/*	s-system	*/
	as = d_vector(nd1);
	gs = d_matrix(nd1, nd1);
	bs = d_vector(nd1);
	hs = d_matrix(nd1, nd1);
	a = d_matrix(nd1, nd1 + 1);

	//---------------------------------------------//
	for (i = 1; i<nd1; i++) {
		for (j = 1; j<nd1; j++) {
			a[i][j] = 0.0;
			gs[i][j] = 0.0;
			hs[i][j] = 0.0;
		}
		bs[i] = 0.0;
		as[i] = 0.0;
	}
	//---------------------------------------------//

	xp0 = d_vector(na1);

	if (error = fopen_s(&fpw, caltime_Ssys, "w") != 0) {
		printf("Cannot open 'solution_Ssys.dat' file curent drive.\n");
		getchar();
		exit(1);
	}

	printf("Initial guesses\n");

	for (i = 1; i<na1; i++) {
		printf("xp[%d]=%.15e\n", i, xp[i]);
		xp0[i] = xp[i];
	}


	printf("\n-*-*-*-*-*-*- S-system method -*-*-*-*-*-*-\n");
	for (i = 1; i<na1; i++) {
		fprintf(fpw, "xp0[%d]=%.15e\n", i, xp0[i]);
	}
	/**********S-system method start************/

	//-------------------------------------------------------------------//
	if (error = fopen_s(&ftws, caltime_output_steady, "a") != 0) {
		printf("Cannot open 'caltime_steady.dat' file curent drive.\n");
		getchar();
		exit(1);
	}
	start_t = GetTickCount();
	fprintf(ftws, "S-system method start:%23.15e\n", (double)start_t);
	fclose(ftws);
	//-------------------------------------------------------------------//

	for (count = 1; count <= trymax; count++) {


		coe_s(xp0, fxp, vp, svp, stoin, as, bs, gs, hs, nd1, ni, cv);

		for (i = 1; i<nd1; i++) {
			for (j = 1; j<nd1; j++) {
				a[i][j] = gs[i][j] - hs[i][j];
			}
			a[i][nd1] = log(bs[i] / as[i]);
		}

		gj(a, nd1, nd1 + 1);

		for (i = 1; i<nd1; i++) {
			xp[i] = exp(a[i][nd1]);
			fprintf(fpw, "%dth\tx[%d]=%.15e\n", count, i, xp[i]);
		}

		if (conv == true && retry == true) {
			printf("Solutions are calculated again.\n");
			max = 0.0;
			for (i = 1; i < nd1; i++) {

				if (max < fabs((xp[i] - xp0[i]) / xp0[i]))
					max = fabs((xp[i] - xp0[i]) / xp0[i]);
			}
			printf("retry:%dth\trelative error(max):%23.15e\n", count, max);
			fprintf(fpw, "Solutions are calculated again.\n");
			fprintf(fpw, "retry:%dth\trelative error(max):%23.15e\n", count, max);
			retry = false;
		}

		if (conv == false) {
			//=============================================
			max = 0.0;
			for (i = 1; i < nd1; i++) {
				if (max < fabs((xp[i] - xp0[i]) / xp0[i]))
					max = fabs((xp[i] - xp0[i]) / xp0[i]);
			}
			printf("%dth\trelative error(max):%23.15e\n", count, max);
			fprintf(fpw, "%dth\trelative error(max):%23.15e\n", count, max);
			//=============================================
			for (i = 1; i < nd1; i++) {			//evaluation

				if (fabs((xp[i] - xp0[i]) / xp0[i]) < eps) {
					conv = true;
					retry = true;
				}
				else {
					conv = false;
					break;
				}
			}
		}

		for (i = 1; i<nd1; i++) {
			xp0[i] = xp[i];
		}

		if (conv == true && retry == false) {
			printf("Solutions are calculated.\n\n");
			break;
		}

		if (conv == false && count == trymax) {
			printf("Not connvergence.\n\n");
			getchar();
			break;
		}

	}

	printf("S-system method : Trial number %d\n", count);

	for (i = 1; i<na1; i++) {
		fprintf(fpw, "x[%d]=%.15e\n", i, xp0[i]);
		xp[i] = xp0[i];
	}

	//-------------------------------------------------------------------
	if (error = fopen_s(&ftws, caltime_output_steady, "a") != 0) {
		printf("Cannot open 'caltime_steady.dat' file curent drive.\n");
		getchar();
		exit(1);
	}
	end_t = GetTickCount();
	fprintf(ftws, "S-system method end:%23.15e\n", (double)end_t);
	mid_t = end_t - start_t;
	fprintf(ftws, "S-system method took %23.15e count [%23.15e sec].\n", (double)mid_t, (double)mid_t / 1000);
	printf("S-system method took %d count [%4.2f sec].\n", mid_t, (double)mid_t / 1000);
	fprintf(ftws, "S-system method : Trial number %d\n", count);
	fprintf(ftws, "S-system method : relative error E=%23.15e\n", eps);
	fclose(ftws);
	//-------------------------------------------------------------------

	/********** S-system method end ************/

	free_d_matrix(nd1, a);
	free(as);
	free(bs);
	free_d_matrix(nd1, gs);
	free_d_matrix(nd1, hs);

	fo(&nd, &ni, &cv, xp0, 1);

	fclose(fpw);
	free(xp0);

	free_d_matrix(nd1, df);

	/*=====================================================*/
	free(xp);
	free(fxp);
	free_d_matrix(nd1, vp);
	free(svp);
	free_d_matrix(nd1, stoin);
}

void coe_s(double *xp, double *fxp, double **vp, double *svp, double **stoin, double *as, double *bs, double **gs, double **hs, int nd1, int ni, int cv)
{
	int i, j, na1;
	double **dv0, **dv1, s, t;

	complex<double> *C_xp, *C_fxp, **C_vp, *C_svp, **C_stoin;

	int cv1;
	na1 = nd1 + ni;
	cv1 = cv + 1;

	dv0 = d_matrix(nd1, nd1);
	dv1 = d_matrix(nd1, nd1);

	C_xp = C_d_vector(na1);
	C_fxp = C_d_vector(nd1);
	C_vp = C_d_matrix(nd1, 2);
	C_svp = C_d_vector(cv1);
	C_stoin = C_d_matrix(nd1, cv1);


	for (j = 1; j<na1; j++)
		C_xp[j] = xp[j];

	for (i = 1; i < nd1; i++) {
		for (j = 1; j < cv1; j++) C_stoin[i][j] = stoin[i][j];
	}


	complex_step2(C_xp, dv0, dv1, C_fxp, C_vp, C_svp, C_stoin, nd1, ni, cv);

	formula(C_xp, C_fxp, C_vp, C_svp, nd1, ni, cv, C_stoin);


	for (i = 1; i<nd1; i++) {
		for (j = 1; j<nd1; j++) {
			gs[i][j] = dv0[i][j] * real(C_xp[j]) / real(C_vp[i][0]);
			hs[i][j] = dv1[i][j] * real(C_xp[j]) / real(C_vp[i][1]);
		}
	}
	for (i = 1; i<nd1; i++) {
		s = 1.0;
		t = 1.0;
		for (j = 1; j<nd1; j++) {
			s = s*pow(real(C_xp[j]), gs[i][j]);
			t = t*pow(real(C_xp[j]), hs[i][j]);
		}
		as[i] = real(C_vp[i][0]) / s;
		bs[i] = real(C_vp[i][1]) / t;
	}
	free_d_matrix(nd1, dv0);
	free_d_matrix(nd1, dv1);

	free(C_xp);
	free(C_fxp);
	free_C_d_matrix(nd1, C_vp);
	free(C_svp);
	free_C_d_matrix(nd1, C_stoin);

}

void complex_step2(complex<double> *C_xp, double **dv0, double **dv1, complex<double> *C_fxp, complex<double> **C_vp, complex<double> *C_svp, complex<double> **C_stoin, int nd1, int ni, int cv)
{
	int i, j, na1, cv1;
	double h = Step;
	double *xp;

	na1 = nd1 + ni;
	cv1 = cv + 1;

	xp = d_vector(na1);

	for (i = 1; i<nd1; i++) {
		for (j = 1; j<nd1; j++) {
			xp[j] = real(C_xp[j]);
			C_xp[j] = xp[j] + iu*h;

			formula(C_xp, C_fxp, C_vp, C_svp, nd1, ni, cv, C_stoin);
			dv0[i][j] = imag(C_vp[i][0]) / h;
			dv1[i][j] = imag(C_vp[i][1]) / h;
			C_xp[j] = xp[j];
		}

		formula(C_xp, C_fxp, C_vp, C_svp, nd1, ni, cv, C_stoin);
	}

	free(xp);
}


void gj(double **a, int nd1, int nd2)
{
	int i, j, k, p, q, k1, *l, n1;
	double a2, a1, a0, d, eps = 10e-5;         //change if necessary.
	l = i_vector(nd1);
	for (i = 1; i<nd1; i++)
		l[i] = i;
	d = 1.0;

	for (k = 1; k<nd1; k++) {
		a1 = fabs(a[k][k]);
		p = k;
		q = k;
		for (j = k; j<nd1; j++) {
			for (i = k; i<nd1; i++) {
				if (a1<fabs(a[i][j])) {
					a1 = fabs(a[i][j]);
					p = i;
					q = j;
				}
			}
		}
		if (a1<eps) {
			printf("singular matrix\n");
			getchar();
			exit(1);
		}
		if (k != p) {
			d = -d;
			for (j = k; j<nd2; j++) {
				a0 = a[k][j];
				a[k][j] = a[p][j];
				a[p][j] = a0;
			}
		}
		if (k != q) {
			d = -d;
			for (i = 1; i<nd1; i++) {
				a0 = a[i][k];
				a[i][k] = a[i][q];
				a[i][q] = a0;
			}
			j = l[k]; l[k] = l[q]; l[q] = j;
		}
		a1 = a[k][k];
		d = d*a1;
		k1 = k + 1;
		for (j = k1; j<nd2; j++)
			a[k][j] = a[k][j] / a1;
		for (i = 1; i<nd1; i++) {
			if (i != k) {
				a2 = a[i][k];
				for (j = k1; j<nd2; j++)
					a[i][j] = a[i][j] - a2*a[k][j];
			}
		}
	}
	n1 = nd2;
	for (j = n1 - 1; j<nd2; j++) {
		for (i = 1; i<nd1; i++) {
			p = l[i];
			a[p][nd1 - 1] = a[i][j];
		}
		for (i = 1; i<nd1; i++)
			a[i][j] = a[i][nd1 - 1];
	}
	free(l);
}


void fo(int *nd, int *ni, int *cv, double *x, int mode)
{
	double na1;
	int i;
	FILE *fp, *fpw;

	na1 = *nd + *ni + 1;
	if (mode == 0) {
		if (error = fopen_s(&fp, input_initial, "r") != 0) {
			printf("Cannot open 'initial.dat' file curent drive.\n");
			getchar();
			exit(1);
		}
		fscanf_s(fp, "%d%d%d%d", &iflagtime, nd, ni, cv);
		for (i = 1; i<na1; i++) {
			fscanf_s(fp, "%lf", &x[i]);
		}
		fclose(fp);
	}
	if (mode == 1) {
		if (error = fopen_s(&fpw, output, "w") != 0) {
			printf("Cannot open 'caltime.dat' file curent drive.\n");
			getchar();
			exit(1);
		}
		fprintf(fpw, "%d\n%d\n%d\n", *nd, *ni, *cv);
		for (i = 1; i<na1; i++) {
			fprintf(fpw, "%23.15e\n", x[i]);
		}
		fclose(fpw);
	}
	if (mode == 2) {
		if (error = fopen_s(&fp, output_pre, "r") != 0) {
			printf("Cannot open 'RK_Conc.dat' file curent drive.\n");
			getchar();
			exit(1);
		}
		fscanf_s(fp, "%d%d%d", nd, ni, cv);
		for (i = 1; i<na1; i++) {
			fscanf_s(fp, "%lf", &x[i]);
		}
		fclose(fp);
	}
}

void fo1(int *nd, int *ni, int *cv)
{
	FILE *fp;

	if (error = fopen_s(&fp, input_initial, "r") != 0) {
		printf("Cannot open 'initial.dat' file curent drive.\n");
		getchar();
		exit(1);
	}
	fscanf_s(fp, "%d%d%d%d", &iflagtime, nd, ni, cv);
	fclose(fp);
}

void fo2(double *t_start, double *t_end, double *t_samp, double *sub_div)
{
	FILE *fp;

	if (error = fopen_s(&fp, input_rungekutta, "r") != 0) {
		printf("Cannot open 'rungekutta.dat' file curent drive.\n");
		getchar();
		exit(1);
	}
	fscanf_s(fp, "%lf%lf%lf%lf", t_start, t_end, t_samp, sub_div);
	fclose(fp);
}

void fo3(int *iflagtime)
{
	FILE *fp;

	if (error = fopen_s(&fp, input_initial, "r") != 0) {
		printf("Cannot open 'initial.dat' file curent drive.\n");
		getchar();
		exit(1);
	}
	fscanf_s(fp, "%d", iflagtime);
	fclose(fp);
}

void fo4(double **stoin, int nd, int ni, int cv)
{
	FILE *fp;
	int i, j, dummy1, nd1, cv1, na1;
	double dummy2;

	if (error = fopen_s(&fp, input_initial, "r") != 0) {
		printf("Cannot open 'initial.dat' file curent drive.\n");
		getchar();
		exit(1);
	}
	fscanf_s(fp, "%d%d%d%d", &dummy1, &dummy1, &dummy1, &dummy1);
	na1 = nd + ni + 1;
	for (i = 1; i<na1; i++) {
		fscanf_s(fp, "%lf", &dummy2);
	}
	nd1 = nd + 1;
	cv1 = cv + 1;
	for (i = 1; i<nd1; i++) {
		for (j = 1; j<cv1; j++) {
			fscanf_s(fp, "%lf", &stoin[i][j]);
		}
	}
	fclose(fp);
}
// *************************************************


double* d_vector(int n)
{
	double *a;
	if ((a = (double*)malloc(n*sizeof(double))) == NULL) {
		printf("memory unavailable\n");
		exit(1);
	}
	return(a);
}

double** d_matrix(int m, int n)
{
	double **a;
	int i;
	if ((a = (double**)malloc(m*sizeof(double*))) == NULL) {
		printf("memory unavailable\n");
		exit(1);
	}
	for (i = 0; i<m; i++) {
		if ((a[i] = (double*)malloc(n*sizeof(double))) == NULL) {
			printf("memory unavailable\n");
			exit(1);
		}
	}
	return(a);
}

int* i_vector(int n)
{
	int *a;
	if ((a = (int*)malloc(n*sizeof(int))) == NULL) {
		printf("memory unavailable\n");
		exit(1);
	}
	return(a);
}

void free_d_matrix(int m, double **a)
{
	int i;
	for (i = 0; i<m; i++)
		free(a[i]);
	free(a);
}

void free_C_d_matrix(int m, complex<double> **a)
{
	int i;
	for (i = 0; i<m; i++)
		free(a[i]);
	free(a);
}

complex<double>* C_d_vector(int n)
{
	complex<double> *a;
	if ((a = (complex<double>*)malloc(n*sizeof(complex<double>))) == NULL) {
		printf("memory unavailable\n");
		exit(1);
	}
	return(a);
}

complex<double>** C_d_matrix(int m, int n)
{
	complex<double> **a;
	int i;
	if ((a = (complex<double>**)malloc(m*sizeof(complex<double>*))) == NULL) {
		printf("memory unavailable\n");
		exit(1);
	}
	for (i = 0; i<m; i++) {
		if ((a[i] = (complex<double>*)malloc(n*sizeof(complex<double>))) == NULL) {
			printf("memory unavailable\n");
			exit(1);
		}
	}
	return(a);
}
