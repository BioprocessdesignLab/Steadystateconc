void formula(complex<double> *x, complex<double> *fx, complex<double> **v, complex<double> *sv, int nd1, int ni, int cv, complex<double> **stoin)
{
	int i, j;
	complex<double> s0;
	complex<double> s1;  
	int cv1;
	cv1 = cv + 1;
	//****************************************************************

	sv[1] = 2.0 * pow(x[4], 1.5) * pow(x[2], -0.5);

	sv[2] = 3.0* pow(x[1], 1.0);
	sv[3] = 1.5* pow(x[2], 1.5)* pow(x[3], 0.5);

	sv[4] = 1.5* pow(x[1], 1.0);
	sv[5] = 2.0* pow(x[3], 0.75);

	//****************************************************************
	for (i = 1; i<nd1; i++) {
		s0 = 0.0;
		s1 = 0.0;
		for (j = 1; j< cv1; j++) {
	
			if (real(stoin[i][j])>0.0) s0 = s0 + stoin[i][j] * sv[j];
			if (real(stoin[i][j])<0.0) s1 = s1 + stoin[i][j] * sv[j];
		}
		v[i][0] = s0;
		v[i][1] = -s1;

		fx[i] = s0 + s1;

	}

}